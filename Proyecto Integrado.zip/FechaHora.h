#ifndef  FechaHora_h
#define  FechaHora_h

#include "Vuelo.h"

class FechaHora{
private:
    Vuelo vuelo;
    int dia;
    int mes;
    int ano;
    int hora;
    int minuto;
public:
    FechaHora();
    FechaHora(string fecha, string hora, Vuelo vuelo);
    FechaHora(int dia, int mes, int ano, int hora, int minuto, Vuelo vuelo);
    void setDia(int dia);
    void setMes(int mes);
    void setAno(int ano);
    void setHora(int hora);
    void setMinuto(int minuto);
    void setVuelo(Vuelo vuelo);
    int getDia();
    int getMes();
    int getAno();
    int getHora();
    int getMinuto();
    string getFecha();
    Vuelo getVuelo();
    string datos();
};

FechaHora::FechaHora(){
    dia = 1;
    mes = 1;
    ano = 2000;
    hora = 0;
    minuto = 0;
    Vuelo vuelo("00-0000","D");

}

FechaHora::FechaHora(string  fecha, string hora) {
    ano = stoi(fecha.substr(0,4));
    mes = stoi(fecha.substr(5,7));
    dia = stoi(fecha.substr(8,10));
    this->hora = stoi(hora.substr(0,2));
    minuto = stoi(hora.substr(3,5));

}

FechaHora::FechaHora(int dia, int mes, int ano, int hora, int minuto,Vuelo vuelo){
    this->dia = dia;
    this->mes = mes;
    this->ano = ano;
    this->hora = hora;
    this->minuto = minuto;
    this->vuelo=vuelo;
}

void FechaHora::setDia(int dia){
    this->dia = dia;
}

void FechaHora::setMes(int mes){
    this->mes = mes;
}

void FechaHora::setAno(int ano){
    this->ano = ano;
}

void FechaHora::setHora(int hora){
    this->hora = hora;
}

void FechaHora::setMinuto(int minuto){
    this->minuto = minuto;
}
void FechaHora::setVuelo(Vuelo vuelo){
    this->vuelo=vuelo;
}


int  FechaHora::getDia(){
    return dia;
}

int  FechaHora::getMes(){
    return mes;
}

int  FechaHora::getAno(){
    return ano;
}

int  FechaHora::getHora(){
    return hora;
}

int  FechaHora::getMinuto(){
    return minuto;
}

string FechaHora::getFecha() {
    return to_string(ano) + "/" + to_string(mes) + "/" + to_string(dia);
}

Vuelo FechaHora::getVuelo(){
    return vuelo;
}

string  FechaHora::datos(){
    string singular_plural;
    if(hora == 1){
        singular_plural = "la ";
    }
    else{
        singular_plural = "las ";
    }

    return  to_string(ano) + "/" + to_string(mes) + "/" + to_string(dia)
          + " a " + singular_plural + to_string(hora) + ":" + to_string(minuto) + ".";
}

#endif