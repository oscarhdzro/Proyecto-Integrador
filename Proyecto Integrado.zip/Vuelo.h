#ifndef Vuelo_h
#define Vuelo_h

class Vuelo{
private:
    string num_vuelo;
    string tipo;
    string aerolinea;
    string destino;
public:
    Vuelo();
    Vuelo(string num_vuelo, string tipo, string aerolinea, string destino);
    void setNum_vuelo(string num_vuelo);
    void setTipo(string tipo);
    void setAerolinea(string aerolinea)
    void setDestino();
    string getDestino();
    string getNum_vuelo();
    string getTipo();
    string getAerolinea();
    void datos();
};

Vuelo::Vuelo(){
    num_vuelo="00-0000";
    tipo="D";
    aerolinea="Default";
    destino="Sin Destino";
}
Vuelo::Vuelo(string num_vuelo, string tipo, string aerolinea, string destino){
    this->num_vuelo=num_vuelo;
    this->tipo=tipo;
    this->aerolinea=aerolinea;
    this->destino=destino;

}

void Vuelo::setAerolinea(string aerolinea){
    this->aerolinea=aerolinea;
}

void Vuelo::setNum_vuelo(string num_vuelo){
    this->num_vuelo=num_vuelo;
}
void Vuelo::setTipo(string tipo){
    this->tipo=tipo;

}
string Vuelo::getNum_vuelo(){
    return num_vuelo;

}
string Vuelo::getAerolinea(){
    return aerolinea;
}
string Vuelo::getTipo(){
    return tipo;
}
void Vuelo::datos(){
    cout<<"Numero de vuelo: "<<num_vuelo<<" Salida o Llegada: "<<tipo<<endl;

}
#endif