#ifndef Avion_h
#define Avion_h

class Avion {
private:
    string avion;
    int pasajeros;
    int capacidad;
    
public:
    Avion();
    Avion(string avion, int pasajeros, int capacidad);
    void setAvion(string avion);
    void setCapacidad(int capacidad);
    void setPasajeros(int pasajeros);
    string getAvion();
    int getCapacidad();
    int getPasajeros();
    void datos();
};

Avion::Avion() {
    avion = "Sin Definir";
    pasajeros=0;
    capacidad = 0;
}
Avion::Avion(string avion, int pasajeros, int capacidad) {
    this->avion = avion;
    this->pasajeros=pasajeros;
    this->capacidad = capacidad;
}
void Avion::setAvion(string avion) {
    this->avion = avion;
}
void Avion::setCapacidad(int capacidad) {
    this->capacidad = capacidad;
}
void Avion::setPasajeros(int pasajeros){
    this->pasajeros=pasajeros;
}
string Avion::getAvion() {
    return avion;
}
int Avion::getCapacidad() {
    return capacidad;
}
int Avion::getPasajeros(){
    return pasajeros;
}
void Avion::datos() {
    cout << "Avion: " << avion <<"Pasajeros: "<<pasajeros<< " Capacidad: " << capacidad << endl;
}

#endif
