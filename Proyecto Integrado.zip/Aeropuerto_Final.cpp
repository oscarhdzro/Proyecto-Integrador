#include <iostream>
#include <string>
#include <fstream>

using namespace std;

#include "Vuelo.h"
#include "Avion.h"
#include "FechaHora.h"

void InicializaHoras(int horas[24]){
  for(int i = 0;i<24;i++){

    horas[i]=0;
  }
}

int BuscaAerolinea[aerolinea]{
   for (int i=0; i<8;i++){
     
    if (aerolinea == aerolineas[i].getAerolinea()){
    
      return i;
    }




//Pregunta 1
void funcionUno(){
    ifstream archivo;
    string datos[2540][9];
    int reng=0;
    int horas[24];

    archivo.open("datos_vuelos.txt");
    while(archivo >> datos[reng][0]>> datos[reng][1]>> datos[reng][2]>> datos[reng][3]>> datos[reng][4]>> datos[reng][5]>> datos[reng][6]>> datos[reng][7]>> datos[reng][8])>> datos[reng][9]){
        reng++;
    }

    InicializaHoras(horas);

    for(int j=0;j<reng;j++){
        if(j>0){
            if(datos[j].getFecha().getFechaStr()!=fecha_str){

            int mayor = 0;
            int hora = 0;

        for (int i=0;i<24;i++) {
             if (horas[i] > mayor) {
                hora = i;
                mayor = horas[i];
        }
        }
      cout<< "Para el día: "<< f.fecha_str <<" "<<"la hora más saturada es: "<<g.getHora;
      cout<<" con "<<mayor <<" vuelos"<<endl;
      InicializaHoras(horas);
      
   
     }
    return 0;
}

//Pregunta 2
void funcionDos(){
    ifstream archivo;
    string datos[2540][9];
    int reng=0;
    int horas[24];
    int cant_llegadass_porhora=0;

    archivo.open("datos_vuelos.txt");
    while(archivo >> datos[reng][0]>> datos[reng][1]>> datos[reng][2]>> datos[reng][3]>> datos[reng][4]>> datos[reng][5]>> datos[reng][6]>> datos[reng][7]>> datos[reng][8])>> datos[reng][9]){
        reng++;
    }
    for (h=0,h<24,h++){
        datos[reng][2];
        while hora!=24;
            if datos[reng][4]=="L";
                cant_llegadas_porhora++
                hora++
            else
            {
                break;
            }

    }
    cout<<"Hora: "<<g.getHora<<"Llegadas: "<<cant_llegadass_porhora<<endl
}   

//Pregunta 3
void funcionTres(){
    ifstream archivo;
    string datos[2540][9];
    int reng=0;
    int horas[24];
    int cant_salidas_porhora=0;

    archivo.open("datos_vuelos.txt");
    while(archivo >> datos[reng][0]>> datos[reng][1]>> datos[reng][2]>> datos[reng][3]>> datos[reng][4]>> datos[reng][5]>> datos[reng][6]>> datos[reng][7]>> datos[reng][8])>> datos[reng][9]){
    reng++;
    }

    for (h=0,h<24,h++){
        datos[reng][2];
        while hora!=24;
            if datos[reng][4]=="S";
                cant_salidas_porhora++
                hora++
            else
            {
                break;
            }

    }
    cout<<"Hora: "<<g.getHora<<"Salidas: "<<cant_salidas_porhora<<endl
}

//Pregunta 4
void funcionCuatro(){
    ifstream archivo;
    string datos[2540][9];
    int reng=0;
    int horas[24];
    int llegas_aero=0;
    int sales_aero=0;

    archivo.open("datos_vuelos.txt");
    while(archivo >> datos[reng][0]>> datos[reng][1]>> datos[reng][2]>> datos[reng][3]>> datos[reng][4]>> datos[reng][5]>> datos[reng][6]>> datos[reng][7]>> datos[reng][8])>> datos[reng][9]){
        reng++;
    }

    int BuscaAerolinea(){
        for (aerolinea[i];i<tamaño_aerolinea;i++){
        if datos[reng][4]=="A";
            llegas_aero++;
        else
            sales_aero++;
        }
    }
    for (int p=0;k<tamaño_aerolinea;p++){
    cout<<"Aerolinea: "<<aerolineas[p].getAerolinea()<<" Salidas: "<<aerolineas[p].getSalidas()<<" Llegadas: "<<aerolineas[p].getLlegadas()<<endl;
    
    }
}
}

//Pregunta 5
void funcionCinco(){
    ifstream archivo;
    string datos[2540][9];
    int reng=0;
    int horas[24];
    int pasajeros_totales=0;
    int suma=0;

    archivo.open("datos_vuelos.txt");
    while(archivo >> datos[reng][0]>> datos[reng][1]>> datos[reng][2]>> datos[reng][3]>> datos[reng][4]>> datos[reng][5]>> datos[reng][6]>> datos[reng][7]>> datos[reng][8])>> datos[reng][9]){
        reng++;
    }

    for (o=0,o<1270,o++){
        pasajeros_totales_1=datos[reng][8]
        pasajeros_totales_1++
    }

    for (o=1270,o<2541,o++){
        p.getPasajeros=0
        pasajeros_totales_2=datos[reng][8]
        pasajeros_totales_2++
    }

    cout<<"Los pasajeros totales en el dia 1 fueron: "<<pasajeros_totales_1<<endl;
    cout<<"Los pasajeros totales en el dia 2 fueron: "<<pasajeros_totales_2<<endl;

}

//Pregunta 6
void funcionSeis(){
    ifstream archivo;
    string datos[2540][9];
    int reng=0;

    archivo.open("datos_vuelos.txt");
    while(archivo >> datos[reng][0]>> datos[reng][1]>> datos[reng][2]>> datos[reng][3]>> datos[reng][4]>> datos[reng][5]>> datos[reng][6]>> datos[reng][7]>> datos[reng][8])>> datos[reng][9]){
        reng++;
    }

    for (r=0,r<2540,r++){
        cout<<"El porcentaje es del vuelo: "<<get.Vuelo<<" es "<<(datos[reng][8]/datos[reng][9])<<endl;
        r++
    }
}

int main(){

    int opcion;

    do{
        cout<<"1. Hora de cada uno de los días que vienen en el archivo con mayor saturación."
            <<"2. Cantidad de llegadas por hora promedio."
            <<"3. Cantidad de salidas por hora promedio."
            <<"4. Cantidad de llegadas y salidas por aerolínea."
            <<"5. Cantidad de pasajeros atendidos por día."
            <<"6. Porcentaje promedio de capacidad utilizada en los aviones"
            <<"7. Salir"
            <<"OPCION:";
        cin>>opcion;

        switch (opcion){

            case 1:
                funcionUno();
                break;

            case 2:
                funcionDos();
                break;

            case 3:
                funcionTres();
                break;

            case 4:
                funcionCuatro();
                break;
            
            case 5:
                funcionCinco();
                break;

            case 6:
                funcionSeis();
                break;
            
            case 7:
                cout <<" FIN DEL PROGRMA "<<endl;
                break;

            default:
                break;
        }
    } while (opcion != 7);

    return 0;
}
